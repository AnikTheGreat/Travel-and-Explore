create table client(
    client_uid varchar2(10) not null,
    client_pass varchar2(20) not null,
    client_fname varchar2(20),
    client_lname varchar2(20),
    client_email varchar2(50),
    client_phone varchar2(20),
    client_district varchar2(20),
    client_subdist varchar2(20),
    client_village varchar2(20),
    primary key (client_uid)
);

create table admin(
    admin_uid varchar2(10) not null,
    admin_pass varchar2(20) not null,
    admin_fname varchar2(20),
    admin_lname varchar2(20),
    admin_email varchar2(50),
    admin_phone varchar2(20),
    admin_district varchar2(20),
    admin_subdist varchar2(20),
    admin_village varchar2(20),
    primary key(admin_uid)
);
insert into query values ('1',to_date('2000-DEC-10','YYYY-MON-DD'),null,'Hi! How are you?',
null,null,null,'Anik123');
insert into query values ('2',to_date('2001-DEC-10','YYYY-MON-DD'),null,'My name is Anik',
null,null,null,'Anik123');
insert into query values ('3',to_date('2002-DEC-10','YYYY-MON-DD'),null,'My name is Anik',
null,null,null,'Anik123');
insert into query values ('4',to_date('2003-DEC-10','YYYY-MON-DD'),null,'My name is Anik',
null,null,null,'Anik123');
insert into query values ('5',to_date('2004-DEC-10','YYYY-MON-DD'),null,'My name is Anik',
null,null,null,'Anik123');
insert into query values ('6',to_date('2005-DEC-10','YYYY-MON-DD'),null,'My name is Anik',
null,null,null,'Anik123');

select * from query;

create table query(
    query_id varchar2(10) not null,
    query_date date,
    query_no number(10),
    client_query varchar2(500),
    admin_reply varchar2(500),
    reply_date date,
    admin_uid varchar2(10),
    client_uid varchar2(10),
    primary key(query_id)
);

create table tour(
    tour_id varchar2(10) not null,
    tour_sdate date,
    tour_edate date,
    tour_ncountry number(10),
    tour_price number(10),
    tour_vplaces varchar2(500),
    tour_meals varchar2(500),
    tour_namesofcountries varchar2(500),
    primary key(tour_id)
);

insert into query (query_id) values ('1234');
insert into query (query_id) values ('1235');
insert into query (query_id) values ('1236');

insert into client (client_uid,client_pass,client_fname,client_lname,
client_email,client_phone,client_district,client_subdist,client_village) values 
('Anik123','abcdef','Sazzatul Islam','Anik','md.sazzatul.islam.anik@gmail.com',
'01712687080','Bogra','Sherpur','Sherpur');




select * from admin;
select * from client;
select * from query;
select * from tour;

commit;