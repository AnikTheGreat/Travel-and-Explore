
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */



public class offer_table extends javax.swing.JFrame {

    /**
     * Creates new form tour_table
     */
    public offer_table() {
        initComponents();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2,dim.height/2-this.getSize().height/2);
        this.setBackground(new Color(0,0,0,0));
        jPanel1.setBackground(new Color(0,0,0,0));
        list.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,18));
        list.getTableHeader().setOpaque(false);
        list.getTableHeader().setBackground(Color.red);
        list.getTableHeader().setForeground(Color.white);
        list.setRowHeight(25);
        listed();
        offer();
        //jTextField6.setBackground(new Color(0,0,0,0));
        jTextField8.setBackground(new Color(0,0,0,0));
        dis_price.setBackground(new Color(0,0,0,0));
       
    }
    
    public offer_table(String uid){
        initComponents();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2,dim.height/2-this.getSize().height/2);
        this.setBackground(new Color(0,0,0,0));
        jPanel1.setBackground(new Color(0,0,0,0));
        list.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,18));
        list.getTableHeader().setOpaque(false);
        list.getTableHeader().setBackground(Color.red);
        list.getTableHeader().setForeground(Color.white);
        list.setRowHeight(25);
        listed();
        offer();
        //jTextField6.setBackground(new Color(0,0,0,0));
        jTextField8.setBackground(new Color(0,0,0,0));
        dis_price.setBackground(new Color(0,0,0,0));
        
        
        
        jLabel16.setText(uid);
    }
    public void listed()
    {   
        DefaultTableModel table = new DefaultTableModel();
        table.addColumn("Name");
        table.addColumn("Price");
        table.addColumn("No of Days");
        table.addColumn("No of Countries");
        table.addColumn("Highlights");
        table.addColumn("Meals Included");
        table.addColumn("Start Date");
        table.addColumn("End Date");
        table.addColumn("Name of countries");
         try{
        //Step-1: For Creating Connection Object
            String url = "jdbc:oracle:thin:@localhost:1521:xe";
            Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
              
            //Step-2: Create Statement Object to Send to Database
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery("select tour_id,tour_price,tour_days,tour_ncountry,tour_vplaces,tour_meals,to_char(tour_sdate,'dd-mon-yyyy') as ts,to_char(tour_edate,'dd-mon-yyyy') as te,tour_nameofcountries from tour ");
        
            while(result.next()){

                table.addRow(new Object[]{
                                result.getString(1),
                                result.getString(2),
                                result.getString(3),
                                result.getString(4),
                                result.getString(5),
                                result.getString(6),
                                result.getString(7),
                                result.getString(8),
                                result.getString(9)});
            }
            list.setModel(table);
       
        }catch(Exception e){
            //EXCEPTIONS
        }
    }
    
    public void offer(){
        DefaultTableModel table1 = new DefaultTableModel();
        table1.addColumn("Offer_NO");
        table1.addColumn("Admin Name");
        table1.addColumn("Tour_Date");
        table1.addColumn("Assigning Date");
        table1.addColumn("Prev_Price");
        table1.addColumn("Offered_Price");
        table1.addColumn("Status");
        
       
         try{
        //Step-1: For Creating Connection Object
            String url = "jdbc:oracle:thin:@localhost:1521:xe";
            Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
              
            //Step-2: Create Statement Object to Send to Database
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery("  select * from at order by offer_no");
        
            while(result.next()){

                table1.addRow(new Object[]{
                                result.getString(1),
                                result.getString(2),
                                result.getString(3),
                                result.getString(4),
                                result.getString(5),
                                result.getString(6),
                                result.getString(7)

                                });
            }
            offer.setModel(table1);
       
        }catch(Exception e){
            //EXCEPTIONS
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        list = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        offer = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        dis_price = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        list.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        list.setFocusable(false);
        list.setIntercellSpacing(new java.awt.Dimension(0, 0));
        list.setRowHeight(25);
        list.setSelectionBackground(new java.awt.Color(204, 0, 0));
        list.setShowVerticalLines(false);
        list.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(list);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 1520, 280));

        offer.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        offer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        offer.setFocusable(false);
        offer.setIntercellSpacing(new java.awt.Dimension(0, 0));
        offer.setRowHeight(25);
        offer.setSelectionBackground(new java.awt.Color(204, 0, 0));
        offer.setShowVerticalLines(false);
        offer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                offerMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(offer);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 450, 1060, 230));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon("F:\\Travel-and-Explore-master\\Travel_&_Explore\\pics\\red back btn.png")); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1460, 40, 80, 40));

        jLabel17.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("percent");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 620, 80, 40));

        jLabel5.setIcon(new javax.swing.ImageIcon("F:\\Travel-and-Explore-master\\Travel_&_Explore\\pics\\Withdraw btn.png")); // NOI18N
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 720, -1, 40));

        jLabel16.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("tanzil");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, 240, 40));

        jLabel15.setFont(new java.awt.Font("Berlin Sans FB", 0, 20)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Admin ID:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 130, 40));

        jLabel14.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Add discounted price:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 620, 170, 40));

        dis_price.setBackground(new java.awt.Color(255, 237, 242));
        dis_price.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        dis_price.setForeground(new java.awt.Color(255, 255, 255));
        dis_price.setText("10");
        dis_price.setBorder(null);
        dis_price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dis_priceActionPerformed(evt);
            }
        });
        jPanel1.add(dis_price, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 620, 40, 40));

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 240, 40));

        jLabel8.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Tour Name: ");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, 130, 40));

        jLabel10.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Tour Price: ");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 560, 130, 40));

        jTextField8.setBackground(new java.awt.Color(255, 237, 242));
        jTextField8.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jTextField8.setForeground(new java.awt.Color(255, 255, 255));
        jTextField8.setBorder(null);
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 560, 240, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon("F:\\Travel-and-Explore-master\\Travel_&_Explore\\pics\\assign special offer.png")); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 720, 260, 40));

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("F:\\Travel-and-Explore-master\\Travel_&_Explore\\pics\\table2.png")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1640, 1040));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 13, 1676, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void listMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listMouseClicked
        // TODO add your handling code here:
        int i = list.getSelectedRow();
       
        TableModel model = list.getModel();
        jLabel4.setText(model.getValueAt(i,0).toString());
        jTextField8.setText(model.getValueAt(i,1).toString());
        
    }//GEN-LAST:event_listMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        String id= jLabel16.getText();
        String name  = jLabel4.getText();
        String price = jTextField8.getText();
        String dprice = dis_price.getText();
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        int flag=0;
        
        int price1=Integer.parseInt(price);
        int dprice1=Integer.parseInt(dprice);
        
        if(price.isEmpty() || dprice.isEmpty()){
            JOptionPane.showMessageDialog(null,"Please Enter all Fields, Thank You.","Display Message",JOptionPane.INFORMATION_MESSAGE);
        }
        
        try{
        Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
        Statement statement = conn.createStatement();
        ResultSet result = statement.executeQuery(" select * from offerview");
                //Step-4: Process the Data of the Database
                while(result.next()){
                    if(result.getString("tour_id").equals(name)){
                         flag = 1;
                    }
                }
        }catch(Exception e){
        
        }
        
        
        
        
        
        if(flag == 1)
        {
            JOptionPane.showMessageDialog(null,"The tour pack is already assigned with an offer","Display Message",JOptionPane.INFORMATION_MESSAGE);
        }
        
        else{ 
        
       
        try {
        
        Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
        
       
   
        CallableStatement myStmt=conn.prepareCall("{call percentage(?,?,?)}");
        
        myStmt.setDouble(1,price1);
        myStmt.setDouble(2,dprice1);
        myStmt.registerOutParameter(3, Types.INTEGER);

        myStmt.execute();
        
        int result=myStmt.getInt(3);
        String result1=Integer.toString(result);

        System.out.println(result);
        
      
        
        
        PreparedStatement pStmt = conn.prepareStatement( "insert into at values(offer_no.nextval,?,?,TO_DATE(sysdate, 'dd/mm/yyyy hh24:mi:ss'),?,?,'Valid')");
        pStmt.setString(1, jLabel16.getText());
        pStmt.setString(2, jLabel4.getText());
        pStmt.setString(3, jTextField8.getText());
        pStmt.setString(4, result1);
        
        
        pStmt.executeUpdate();
        
        
        pStmt = conn.prepareStatement( "commit");
        pStmt.executeQuery();
        }catch(Exception e){
        
        }
      
            
               JOptionPane.showMessageDialog(null,"Offer Assigned. Thank You.",
                    "Display Message",JOptionPane.INFORMATION_MESSAGE);
               offer();
               
        }
         
            
                
        
     
        
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        String str = jLabel16.getText();
        Admin_page obj=new Admin_page(str);
        obj.setVisible(true);
        dispose();     
    }//GEN-LAST:event_jLabel2MouseClicked

    private void dis_priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dis_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dis_priceActionPerformed

    private void offerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_offerMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_offerMouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
        int i = offer.getSelectedRow();
         TableModel model = offer.getModel();
         
         if(offer.getSelectedRowCount()==1)
         {
                 String s=model.getValueAt(i,0).toString();
                 
                 try{
                 String url = "jdbc:oracle:thin:@localhost:1521:xe";
                 Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");

       
        
                        PreparedStatement pStmt = conn.prepareStatement( "update at set flag='Expired' where offer_no=?");
                        pStmt.setString(1, s);
                        pStmt.executeQuery();
                        pStmt=conn.prepareStatement( "commit");
                        pStmt.executeQuery();
                        
                 }catch(Exception e){
                     
                 }
         
             
             JOptionPane.showMessageDialog(null,"Offer withdrawn", "Display Message",JOptionPane.INFORMATION_MESSAGE);
             offer();
        
         
         }else{
             JOptionPane.showMessageDialog(null,"Please select a package.", "Display Message",JOptionPane.INFORMATION_MESSAGE);
        
         }
        
        
        
        
    }//GEN-LAST:event_jLabel5MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tour_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tour_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tour_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tour_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new offer_table().setVisible(true);
            }
        });
    }
    
    
    public void update(String a,String b,String c){
                  
                String query = "  UPDATE tour set "+a+" = '"+b+"' where tour_id = '"+c+"'";
               // System.out.println(query);
                
                
                try{
                    //Step-1: For Creating Connection Object
                    String url = "jdbc:oracle:thin:@localhost:1521:xe";
                    Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
                
                    //Step-2: Create Statement Object to Send to Database
                    Statement statement = conn.createStatement();
                
                    //In order to send query to database we have to Execute Statements
                    //Step-3: Execute the Statement Object and Receive the Data 
                    statement.executeQuery(query);
                    statement.executeQuery("commit");                
                }
                catch(Exception e){
                    // EXCEPTIONS                

                }
                
             
    }
    public void update1(String a,String b,String c){
                  
                String query = "  UPDATE tour set "+a+" = "+b+" where tour_id = '"+c+"'";
                //System.out.println(query);
                
                
                try{
                    //Step-1: For Creating Connection Object
                    String url = "jdbc:oracle:thin:@localhost:1521:xe";
                    Connection conn = DriverManager.getConnection(url,"tour_management","tour_management");
                
                    //Step-2: Create Statement Object to Send to Database
                    Statement statement = conn.createStatement();
                
                    //In order to send query to database we have to Execute Statements
                    //Step-3: Execute the Statement Object and Receive the Data 
                    statement.executeQuery(query);
                    statement.executeQuery("commit");                
                }
                catch(Exception e){
                    // EXCEPTIONS                

                }
                
             
    }
    
    public void delete_table(){
        
        DefaultTableModel model=(DefaultTableModel)list.getModel();
        
        while(model.getRowCount()>0){
            for(int i=0 ; i<model.getRowCount();i++)
                model.removeRow(i);
        }
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField dis_price;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTable list;
    private javax.swing.JTable offer;
    // End of variables declaration//GEN-END:variables
}

